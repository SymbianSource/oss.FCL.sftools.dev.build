#include "job.h"
extern int autodepend_start_remote_job (struct child *child,char **argv, char **envp, int stdin_fd,
		int *is_remote, int *id_ptr, int *used_stdin);
extern void autodepend_start PARAMS ((struct file *file));
extern void autodepend_end PARAMS ((struct file *file));
extern void autodepend_execute_job PARAMS ((struct child *child,int stdin_fd, int stdout_fd, char **argv, char **envp));
extern int file_audit;
extern int autodepend;

void remote_catch_access(int id,char *line);

extern int check_autodepend(char *filename,char * magic); 
