int cc_get_version(char *filename,char *version);
