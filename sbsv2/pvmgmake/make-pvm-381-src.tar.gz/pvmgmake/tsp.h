int tsp_get_timestamp(char *filename,char *tsp);

