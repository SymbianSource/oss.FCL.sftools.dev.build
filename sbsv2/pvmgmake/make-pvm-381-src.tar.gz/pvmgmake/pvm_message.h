#ifndef _PVMMESSAGE_H_
#define _PVMMESSAGE_H_
enum pvmMessage {
/* Pvm management */
  pvmMakeMng,
  pvmMakeLoadAvg,
/* Output */
  pvmMakeStdout,
  pvmMakeStderr,
/* Dependanciess */
  pvmMakeDepend,
/* Job Server */
  pvmMakeSlotReq,
  pvmMakeSlotAck,
  pvmMakeSlotIsMakefile,
/* Child management */  
  pvmMakeEndTask,
  pvmMakeChildDead
};

#define PVMGMAKE_IOBUFFERSIZE 65536 

#endif
