int cvs_get_cvsinfo(char *filename,char *date,char *version);
int cvs_get_workdate(char *filename,char *date);
int cvs_clean_cache();
