#include <stdio.h>
/* lstat */
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

/* ctime */
#include <time.h>

#include "tsp.h"




int tsp_get_timestamp(char *filename,char *tsp){
  struct stat buf;
  int ret = 1;
  if (lstat(filename,&buf ) == 0) {
    struct tm * date;

    date = gmtime(&buf.st_mtime);
    
    sprintf(tsp,"%04d%02d%02d_%02d%02d%02d",
      	    date->tm_year+1900,date->tm_mon + 1,date->tm_mday,
	    date->tm_hour,date->tm_min,date->tm_sec);

    return 0;
  }
  return 1;  
}
