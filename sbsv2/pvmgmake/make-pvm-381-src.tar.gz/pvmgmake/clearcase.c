#include <stdio.h>

#include "clearcase.h"




int cc_get_version(char *filename,char *version){
  char cmd[256];
  char buf[256];
  FILE *p;
  int ret = 1;
    sprintf(cmd,"cleartool describe -fmt '%%Vn\n' %s 2>/dev/null",filename);

    p = popen(cmd,"r");
    while (fgets(cmd,250,p)) {
      sscanf(cmd,"%s\n",version);
    }
    ret += 0xFF & pclose(p);
    if (version[0] == '/') ret  = 1;
    return ret;

}

#ifdef TEST
main (int argc,char ** argv) {
  char version[256];
  int ret;
  
  ret = cc_get_version(argv[1],version);
    printf("%s:%s %d\n",argv[1],version,ret );
}
#endif
