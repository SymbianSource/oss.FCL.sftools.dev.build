int rcs_get_version(char *filename,char *version);
int rcs_diff(char *filename,char *version);
